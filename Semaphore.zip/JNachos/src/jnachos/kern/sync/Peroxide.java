/**
 *  <MakeWater Problem>
 *  Author: Jae C. Oh
 *
 *  Created by Patrick McSweeney on 12/17/08.
 */
package jnachos.kern.sync;

import java.io.*;
import jnachos.kern.*;

/**
 *
 */

//new file for lab exercise
//i have used the same concept which is there for water.java 
//the Hatom part is same since we need 2 hydrogen atoms
//but the only  modification is in peroxide part

public class Peroxide 
{

    /** Semaphore H */
	// five semaphores
    static Semaphore H = new Semaphore("SemH", 0);

    /** */
    static Semaphore O = new Semaphore("SemO", 0);

    /** */
    static Semaphore wait = new Semaphore("wait", 0);

    /** */
    static Semaphore mutex = new Semaphore("MUTEX", 1);

    /** */
    static Semaphore mutex1 = new Semaphore("MUTEX1", 1);

    /** */
    static long count = 0;

    static long count1 = 0;

    /** */
    static int Hcount, Ocount, nH, nO;

    /** */
    class HAtom implements VoidFunctionPtr
    {
        int mID;

        /**
         *
         */
        public HAtom(int id) {
            mID = id;
        }

        /**
         * oAtom will call oReady. When this atom is used, do continuous
         * "Yielding" - preserving resource
         */
        public void call(Object pDummy) 
        {
            mutex.P();
            if (count % 2 == 0) // first H atom
            {
                count++; // increment counter for the first H
                mutex.V(); // Critical section ended
                H.P(); // Waiting for the second H atom
            } else // second H atom
            {
                count++; // increment count for next first H
                mutex.V(); // Critical section ended
                H.V(); // wake up the first H atom
                O.V(); // wake up O atom
            }

            wait.P(); // wait for water message done

            System.out.println("H atom #" + mID + " used in making peroxide.");
        }
    }

    /** */
    class OAtom implements VoidFunctionPtr
    {
        int mID;

        /**
         * oAtom will call oReady. When this atom is used, do continuous
         * "Yielding" - preserving resource
         */
        public OAtom(int id) {
            mID = id;
        }

        /**
         * oAtom will call oReady. When this atom is used, do continuous
         * "Yielding" - preserving resource
         */
        
        // i have made modifications here for hydrogen peroxide formula
        
        public void call(Object pDummy) 
        {
            //O.P();
            mutex1.P();
            if (count1 % 2 == 0) // for the first Oatom
            	
            {
                count1++; // increment counter for the first O
                //mutex1.V();
                
                System.out.println("O atom #" + mID + " used in making peroxide.");
                
            } 
            else 
            	if ((Hcount-2>=0)&&(Ocount-2>=0))
            	{ 
            		
            		// for the second Oatom
            		
                count1++; //increment counter for the second Oatom
                
                makeWater(); //making water
                
                wait.V(); // wake up H atoms and they will return to
                
                wait.V(); // resource pool
                
                //number of Hatom decremented by 2
                Hcount = Hcount - 2;
                
                //since we need 2 oxygen atoms here for making formula
                Ocount = Ocount - 2;
                
                //printing message
                System.out.println("Numbers Left: H Atoms: " + Hcount + ", O Atoms: " + Ocount);
                
                System.out.println("Numbers Used: H Atoms: " + (nH - Hcount) + ", O Atoms: " + (nO - Ocount));
                System.out.println("O atom #" + mID + " used in making peroxide.");
                //mutex1.V();
            }

            mutex1.V();
        }
    }

    /**
     * oAtom will call oReady. When this atom is used, do continuous "Yielding"
     * - preserving resource
     */
    public static void makeWater() {
        System.out.println("* Peroxide made! Splash!! *");
    }

    /**
     * oAtom will call oReady. When this atom is used, do continuous "Yielding"
     * - preserving resource
     */
    public Peroxide() {
        runWater();
    }

    /**
     *
     */
    public void runWater() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Number of H atoms ? ");
            nH = (new Integer(reader.readLine())).intValue();
            System.out.println("Number of O atoms ? ");
            nO = (new Integer(reader.readLine())).intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Hcount = nH;
        Ocount = nO;

        for (int i = 0; i < nH; i++) {
            HAtom atom = new HAtom(i);
            (new NachosProcess(new String("hAtom" + i))).fork(atom, null);
        }

        for (int j = 0; j < nO; j++) {
            OAtom atom = new OAtom(j);
            (new NachosProcess(new String("oAtom" + j))).fork(atom, null);
        }
    }
}