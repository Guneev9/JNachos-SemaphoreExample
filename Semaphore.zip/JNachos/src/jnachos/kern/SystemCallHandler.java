/**
 * Copyright (c) 1992-1993 The Regents of the University of California.
 * All rights reserved.  See copyright.h for copyright notice and limitation 
 * of liability and disclaimer of warranty provisions.
 *  
 *  Created by Patrick McSweeney on 12/5/08.
 */
package jnachos.kern;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import jnachos.filesystem.OpenFile;
import jnachos.machine.*;

/** The class handles System calls made from user programs. */
public class SystemCallHandler {
	/** The System call index for halting. */
	public static final int SC_Halt = 0;

	/** The System call index for exiting a program. */
	public static final int SC_Exit = 1;

	/** The System call index for executing program. */
	public static final int SC_Exec = 2;

	/** The System call index for joining with a process. */
	public static final int SC_Join = 3;

	/** The System call index for creating a file. */
	public static final int SC_Create = 4;

	/** The System call index for opening a file. */
	public static final int SC_Open = 5;

	/** The System call index for reading a file. */
	public static final int SC_Read = 6;

	/** The System call index for writing a file. */
	public static final int SC_Write = 7;

	/** The System call index for closing a file. */
	public static final int SC_Close = 8;

	/** The System call index for forking a forking a new process. */
	public static final int SC_Fork = 9;

	/** The System call index for yielding a program. */
	public static final int SC_Yield = 10;

	
	//added code for  project-1-----------------------------------------------------
	//Used to create unique PID values. Increments to the next integer once a 
		//PID value is assigned to a new NachosProcess
		public static int count = 0;
		
		//list to maintain process detail
		//A list containing all the current processes in the system. 
		//This is primarily used for looking up processes and checking to see if they exist/checking their status.
		public static ArrayList<NachosProcess> process_list = new ArrayList<>();
		
		//This hash map holds a mapping from processes that are waiting on other 
		//processes to finish to a list of the processes it's waiting on.
		public static HashMap<Integer, ArrayList<Integer>> map = new HashMap<>();
	
	/**
	 * Entry point into the Nachos kernel. Called when a user program is
	 * executing, and either does a syscall, or generates an addressing or
	 * arithmetic exception.
	 * 
	 * For system calls, the following is the calling convention:
	 * 
	 * system call code -- r2 arg1 -- r4 arg2 -- r5 arg3 -- r6 arg4 -- r7
	 * 
	 * The result of the system call, if any, must be put back into r2.
	 * 
	 * And don't forget to increment the pc before returning. (Or else you'll
	 * loop making the same system call forever!
	 * 
	 * @pWhich is the kind of exception. The list of possible exceptions are in
	 *         Machine.java
	 **/
	public static void handleSystemCall(int pWhichSysCall) 
	{

		Debug.print('a', "!!!!" + Machine.read1 + "," + Machine.read2 + "," + Machine.read4 + "," + Machine.write1 + ","
				+ Machine.write2 + "," + Machine.write4);
       	
		//This is done in order to increment the program counters(Machine.java file)
		//PCReg value is moved to PrevPCReg value and NextPCReg Value is moved to PCReg value
		//Then PCReg + 4 to NextPCReg(MipsSim.java) 
		//Registers are maintained using mRegisters[] array
		
		Machine.mRegisters[Machine.PrevPCReg] = Machine.mRegisters[Machine.PCReg]; 
		Machine.mRegisters[Machine.PCReg] = Machine.mRegisters[Machine.NextPCReg];
		Machine.mRegisters[Machine.NextPCReg] = Machine.mRegisters[Machine.NextPCReg] + 4;

		switch (pWhichSysCall) 
		{
		// If halt is system call is invoked, we have to shut down
		
		case SC_Halt:
			Debug.print('a', "Shutdown, initiated by user program.");
			Interrupt.halt();
			break;
	
		case SC_Fork:
			System.out.println("SC FORK System call" + SC_Fork);

			// here, the first thing is to disable the interrupt because, at the time of system call, 
			//if an interrupt occurs,it will create a problem
			//storing its old state, so that we can return to it's initial state in a variable and then turning it to false
		
			boolean interrupt_state = Interrupt.setLevel(false);
			
			//result of system call will go in r2 register, putting value 0
			Machine.writeRegister(2, 0);
			
			// Create a new JNachos Child Process
			NachosProcess child_process = new NachosProcess("");
			
			//once,created we have to set an address space for child
			//This is done by copying the space of parent process to new space for the child
			//in order to set memory for the child process
			
			child_process.setSpace(new AddrSpace(JNachos.getCurrentProcess().getSpace()));	
			
			//we will copy the parent's registers for child register's
			child_process.saveUserState();
			
			
			process_list.add(child_process);
			
			Machine.writeRegister(2, child_process.P_id);
			
			
			//here, we will call NachosProcess.java fork function in order to make child ready
			child_process.fork(new ForkedProcess(), child_process);
			
			// here, we will again enable interrupt by restoring it to its old state
			Interrupt.setLevel(interrupt_state);
			break;
			
			
			
			//Join system call
		case SC_Join:
			System.out.println("SC JOIN System call" + SC_Join);

			//again disabling the interrupt 
			interrupt_state = Interrupt.setLevel(false);
			
			//getting the process id 
			int P_id_value = Machine.readRegister(4);

		
			//now, if the process id is parent process id , then join should return 
			//if process id is an invalid process id or process is already completed then also 
			//it should return 
			
			if ((P_id_value == 0) || (P_id_value == JNachos.getCurrentProcess().P_id) || (P_id_value >= count))
			{
				Interrupt.setLevel(interrupt_state);
				break;
			}
			NachosProcess p = null;
			
			//if the process which is running now is in Syscall list(process_list)
			//means it's a child process, return
			for(NachosProcess process : process_list) 
			{
				if(process.P_id == P_id_value) 
				{
					p = process;
					break;
				}
			}
			
			//we will put current process to sleep till  process with PID in r4 exists
			if (p != null)
			{
				
			System.out.println("Process with " + JNachos.getCurrentProcess().P_id + " sleeping for process: " + P_id_value + "to finish");

			
			ArrayList<Integer> process_wait;
			if (map.containsKey(JNachos.getCurrentProcess().P_id))
				process_wait = map.get(JNachos.getCurrentProcess().P_id);
			else
				process_wait = new ArrayList<>();

			process_wait.add(P_id_value);
			map.put(JNachos.getCurrentProcess().P_id, process_wait);
			Interrupt.setLevel(interrupt_state);
			//making it to sleep
				JNachos.getCurrentProcess().sleep();
			}
			
			//resetting interrupt again
			Interrupt.setLevel(interrupt_state);
			break;
			

			case SC_Exit:
				
				//for display output
				System.out.println("SC EXIT System call" + SC_Exit);
				
				//disable interrupt
				interrupt_state = Interrupt.setLevel(false);
				
				// Read in any arguments from the 4th register
				int arg = Machine.readRegister(4);

				//list 
				ArrayList<Integer>  process_wait = new ArrayList<>();
				
				//here, we are checking on process id whether it  is ther in hashmap or not
				//if yes, it means that there is one process at least which is waiting for it to finish.
				//return the interrupt level to its previous state, and finally call finish on the exiting process.
				
				for (Map.Entry<Integer, ArrayList<Integer>> i : map.entrySet())
				{
					//i is set of mapping from hash map
					//i.getvalue() will return the value of current entry in map
					ArrayList<Integer> list = i.getValue();

					//remove the process from process's list 
					if (list.contains(JNachos.getCurrentProcess().P_id))
					{
						list.remove(new Integer(JNachos.getCurrentProcess().P_id));

						//in case the list is empty now
						//then, remove this entry from map
						if (list.isEmpty())
						{
							//here key is process waiting on other process,we are adding it to waiting list
							process_wait.add(i.getKey());
							//remove the entry
							map.remove(i.getKey());
						}
						else
							
							map.put(i.getKey(), list);
					}
				}
				process_list.remove(JNachos.getCurrentProcess());
 

				for (Integer pr : process_wait) 
				{
					
					NachosProcess process_sleeping = null;
					
					//find process that were waiting on the exit process to finish 
					//by searching the list of current processes
					for(NachosProcess process : process_list) 
					{
						if (pr.equals(process.P_id))
						{
							process_sleeping = process;
							break;
						}
					}

					if (process_sleeping != null) 
					{
						//write the output of exit process to r2
						process_sleeping.writetoUserReg(2,arg);
						Scheduler.readyToRun(process_sleeping);
					}
				}

				//restore interrupt
				Interrupt.setLevel(interrupt_state);
				
				System.out.println("Current Process " + JNachos.getCurrentProcess().P_id + " exiting with code " + arg);

				// Finish the invoking process
				System.out.println("EXIT");
				
				JNachos.getCurrentProcess().finish();
				
				break;

			case SC_Exec:
				
				//for display output
				System.out.println("SC EXEC System call " + SC_Exec);
				
				//disable interrupt
				interrupt_state = Interrupt.setLevel(false);

				//reading r4 to get start point of file name
				int start_file = Machine.readRegister(4);
				
				//getting the current process
				NachosProcess cp = JNachos.getCurrentProcess();
				
				//retrieving file name from memory
				String f_name = cp.FileRead(start_file);
				
				//open it
				OpenFile open = JNachos.mFileSystem.open(f_name);
				
				//if file is null(empty)
				if (open == null) 
				{
					//return from system call
					System.out.println("File is null,return from system call");
					break;
				}
				
				//over write the current addr space from this file's addr space
				cp.setSpace(new AddrSpace(open));
				
				//initialize the registers
				cp.getSpace().initRegisters();
				
				//restoring the state
				cp.getSpace().restoreState();
				
				//restore the previous state of interrupt
				Interrupt.setLevel(interrupt_state);
				
				//run process
				Machine.run();
				
				break;

		default:
			Interrupt.halt();
			break;
		}
	
		
	}
}
